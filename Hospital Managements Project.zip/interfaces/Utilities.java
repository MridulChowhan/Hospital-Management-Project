package interfaces;
import classes.medical;
public interface Utilities{
  
  public void new_medi();

}