package interfaces;
import classes.doctor;
public interface Hospital{

   public void new_doctor();
   


}