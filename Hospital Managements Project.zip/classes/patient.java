package classes;
import interfaces.*;
import java.util.Scanner;
public class patient
{
 public   String pid, pname, disease, gender;
 public   int age;
    public void new_patient()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("ID:");
        pid = input.nextLine();
        System.out.println("Name:");
        pname = input.nextLine();
        System.out.println("Disease:");
        disease = input.nextLine();
        System.out.println("Gender:");
        gender = input.nextLine();
       
        System.out.print("Age:");
        age = input.nextInt();
    }
   public void patient_info()
    {
        System.out.println(pid + "\t" + pname + " \t" + disease + "     \t" + gender + "      \t" + age);
    }
}