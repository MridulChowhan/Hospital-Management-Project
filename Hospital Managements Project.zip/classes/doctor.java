
package classes;
import interfaces.*;
import java.util.Scanner;
public class doctor implements Hospital
{
    public String did, dname, specilist, appoint, doc_qual;
   public int droom;
  public  void new_doctor()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("ID:");
        did = input.nextLine();
        System.out.println("Name:");
        dname = input.nextLine();
        System.out.println("Specilization:");
        specilist = input.nextLine();
        System.out.println("Work time:");
        appoint = input.nextLine();
        System.out.println("Qualification:");
        doc_qual = input.nextLine();
        System.out.println("Room no.:");
        droom = input.nextInt();
    }
    public void doctor_info()
    {
        System.out.println(did + "\t" + dname + " \t" + specilist + "     \t" + appoint + "      \t" +  "\t" + doc_qual);
    }
}

